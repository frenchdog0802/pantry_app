import React, { useState } from 'react';
import { ArrowLeftIcon, PlusIcon, TrashIcon, SearchIcon, CalendarIcon, EditIcon, XIcon, ImageIcon, PackageIcon, UtensilsIcon } from 'lucide-react';
import { usePantry } from '../contexts/PantryContext';
interface ReceiptManagerProps {
  onBack: () => void;
}
export function ReceiptManager({
  onBack
}: ReceiptManagerProps) {
  const {
    receipts,
    addReceipt,
    updateReceipt,
    deleteReceipt,
    updatePantryItems,
    pantryItems
  } = usePantry();
  const [searchQuery, setSearchQuery] = useState('');
  const [showAddReceipt, setShowAddReceipt] = useState(false);
  const [selectedReceipt, setSelectedReceipt] = useState<any>(null);
  const [isEditing, setIsEditing] = useState(false);
  const [activeTab, setActiveTab] = useState('all'); // 'all', 'meals', 'groceries'
  const [newReceipt, setNewReceipt] = useState({
    date: new Date().toISOString().split('T')[0],
    store: '',
    items: [{
      name: '',
      quantity: 1,
      unit: '',
      price: 0
    }],
    total: 0,
    image: null as string | null,
    mealInfo: null as any
  });
  // Filter receipts based on search query and active tab
  const filteredReceipts = receipts.filter(receipt => {
    const matchesSearch = receipt.store.toLowerCase().includes(searchQuery.toLowerCase()) || receipt.items.some(item => item.name.toLowerCase().includes(searchQuery.toLowerCase())) || receipt.mealInfo && receipt.mealInfo.name.toLowerCase().includes(searchQuery.toLowerCase());
    if (activeTab === 'meals') {
      return matchesSearch && !!receipt.mealInfo;
    } else if (activeTab === 'groceries') {
      return matchesSearch && !receipt.mealInfo;
    }
    return matchesSearch;
  });
  // Handle image upload
  const handleImageUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      const reader = new FileReader();
      reader.onload = event => {
        if (isEditing && selectedReceipt) {
          setSelectedReceipt({
            ...selectedReceipt,
            image: event.target?.result as string
          });
        } else {
          setNewReceipt({
            ...newReceipt,
            image: event.target?.result as string
          });
        }
      };
      reader.readAsDataURL(file);
    }
  };
  // Add a new item to the receipt
  const handleAddReceiptItem = () => {
    if (isEditing && selectedReceipt) {
      setSelectedReceipt({
        ...selectedReceipt,
        items: [...selectedReceipt.items, {
          name: '',
          quantity: 1,
          unit: '',
          price: 0
        }]
      });
    } else {
      setNewReceipt({
        ...newReceipt,
        items: [...newReceipt.items, {
          name: '',
          quantity: 1,
          unit: '',
          price: 0
        }]
      });
    }
  };
  // Update receipt item
  const handleUpdateReceiptItem = (index: number, field: string, value: any) => {
    if (isEditing && selectedReceipt) {
      const updatedItems = [...selectedReceipt.items];
      updatedItems[index] = {
        ...updatedItems[index],
        [field]: field === 'price' || field === 'quantity' ? parseFloat(value) || 0 : value
      };
      setSelectedReceipt({
        ...selectedReceipt,
        items: updatedItems,
        total: selectedReceipt.mealInfo ? 0 : updatedItems.reduce((sum, item) => sum + item.price * item.quantity, 0)
      });
    } else {
      const updatedItems = [...newReceipt.items];
      updatedItems[index] = {
        ...updatedItems[index],
        [field]: field === 'price' || field === 'quantity' ? parseFloat(value) || 0 : value
      };
      setNewReceipt({
        ...newReceipt,
        items: updatedItems,
        total: newReceipt.mealInfo ? 0 : updatedItems.reduce((sum, item) => sum + item.price * item.quantity, 0)
      });
    }
  };
  // Update meal info
  const handleUpdateMealInfo = (field: string, value: string) => {
    if (isEditing && selectedReceipt && selectedReceipt.mealInfo) {
      setSelectedReceipt({
        ...selectedReceipt,
        mealInfo: {
          ...selectedReceipt.mealInfo,
          [field]: value
        }
      });
    }
  };
  // Remove receipt item
  const handleRemoveReceiptItem = (index: number) => {
    if (isEditing && selectedReceipt) {
      const updatedItems = selectedReceipt.items.filter((_, i) => i !== index);
      setSelectedReceipt({
        ...selectedReceipt,
        items: updatedItems,
        total: selectedReceipt.mealInfo ? 0 : updatedItems.reduce((sum, item) => sum + item.price * item.quantity, 0)
      });
    } else {
      const updatedItems = newReceipt.items.filter((_, i) => i !== index);
      setNewReceipt({
        ...newReceipt,
        items: updatedItems,
        total: newReceipt.mealInfo ? 0 : updatedItems.reduce((sum, item) => sum + item.price * item.quantity, 0)
      });
    }
  };
  // Save receipt
  const handleSaveReceipt = () => {
    if (isEditing && selectedReceipt) {
      updateReceipt(selectedReceipt);
      setSelectedReceipt(null);
      setIsEditing(false);
    } else {
      addReceipt(newReceipt);
      setNewReceipt({
        date: new Date().toISOString().split('T')[0],
        store: '',
        items: [{
          name: '',
          quantity: 1,
          unit: '',
          price: 0
        }],
        total: 0,
        image: null,
        mealInfo: null
      });
      setShowAddReceipt(false);
    }
  };
  // Add items from receipt to pantry
  const handleAddItemsToPantry = (receiptItems: any[]) => {
    const updatedPantry = [...pantryItems];
    receiptItems.forEach(item => {
      // Check if item already exists in pantry
      const existingItemIndex = updatedPantry.findIndex(pantryItem => pantryItem.name.toLowerCase() === item.name.toLowerCase());
      if (existingItemIndex >= 0) {
        // Update quantity if item exists
        updatedPantry[existingItemIndex] = {
          ...updatedPantry[existingItemIndex],
          quantity: updatedPantry[existingItemIndex].quantity + item.quantity
        };
      } else if (item.name.trim()) {
        // Add new item to pantry
        updatedPantry.push({
          name: item.name,
          quantity: item.quantity,
          unit: item.unit
        });
      }
    });
    updatePantryItems(updatedPantry);
  };
  // Get meal type label
  const getMealTypeLabel = (type: string) => {
    switch (type) {
      case 'breakfast':
        return 'Breakfast';
      case 'lunch':
        return 'Lunch';
      case 'dinner':
        return 'Dinner';
      case 'snack':
        return 'Snack';
      default:
        return 'Meal';
    }
  };
  return <div className="flex flex-col w-full min-h-screen bg-gray-50">
      {/* Header */}
      <header className="bg-gradient-to-r from-orange-500 to-red-600 text-white p-5 shadow-md">
        <div className="container mx-auto flex justify-between items-center">
          <button onClick={onBack} className="p-2 rounded-full hover:bg-white/20 transition-colors" aria-label="Go back">
            <ArrowLeftIcon size={24} />
          </button>
          <h1 className="text-xl font-bold">Receipt Manager</h1>
          <div className="w-10"></div> {/* For layout balance */}
        </div>
      </header>
      {/* Main Content */}
      <main className="flex-1 container mx-auto p-5">
        {!showAddReceipt && !selectedReceipt ? <>
            {/* Tabs */}
            <div className="flex mb-6 bg-white rounded-xl overflow-hidden shadow-sm border border-gray-200">
              <button onClick={() => setActiveTab('all')} className={`flex-1 py-3 px-4 font-medium ${activeTab === 'all' ? 'bg-red-50 text-red-600' : 'text-gray-700'}`}>
                All
              </button>
              <button onClick={() => setActiveTab('meals')} className={`flex-1 py-3 px-4 font-medium ${activeTab === 'meals' ? 'bg-red-50 text-red-600' : 'text-gray-700'}`}>
                Meals
              </button>
              <button onClick={() => setActiveTab('groceries')} className={`flex-1 py-3 px-4 font-medium ${activeTab === 'groceries' ? 'bg-red-50 text-red-600' : 'text-gray-700'}`}>
                Groceries
              </button>
            </div>
            {/* Search Bar */}
            <div className="relative mb-6">
              <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
                <SearchIcon size={18} className="text-gray-400" />
              </div>
              <input type="text" placeholder="Search receipts..." value={searchQuery} onChange={e => setSearchQuery(e.target.value)} className="w-full pl-10 pr-4 py-3 rounded-xl border border-gray-200 focus:outline-none focus:ring-2 focus:ring-red-500 focus:border-transparent" />
            </div>
            {/* Add New Receipt Button */}
            <button onClick={() => setShowAddReceipt(true)} className="w-full flex items-center justify-center gap-2 bg-white border border-gray-200 hover:bg-gray-50 text-gray-800 font-medium py-3 px-4 rounded-xl mb-6 shadow-sm transition-colors">
              <PlusIcon size={18} />
              <span>Add New Receipt</span>
            </button>
            {/* Receipts List */}
            <div className="bg-white rounded-xl shadow-sm border border-gray-100 overflow-hidden">
              <div className="p-4 border-b border-gray-100 bg-gray-50">
                <h2 className="font-semibold text-gray-800">
                  {activeTab === 'all' ? 'All Records' : activeTab === 'meals' ? 'Meal Records' : 'Grocery Receipts'}
                </h2>
              </div>
              {filteredReceipts.length === 0 ? <div className="p-6 text-center">
                  <p className="text-gray-500">No receipts found</p>
                  {searchQuery && <p className="text-gray-400 text-sm mt-1">
                      Try a different search term
                    </p>}
                </div> : <ul className="divide-y divide-gray-100">
                  {filteredReceipts.map(receipt => <li key={receipt.id} className="p-4">
                      <div className="flex justify-between">
                        <div className="flex-1 cursor-pointer" onClick={() => {
                  setSelectedReceipt(receipt);
                  setIsEditing(false);
                }}>
                          <div className="flex items-center mb-1">
                            {receipt.mealInfo ? <>
                                <UtensilsIcon size={16} className="text-red-500 mr-2" />
                                <h3 className="font-medium text-gray-800">
                                  {receipt.mealInfo.name}{' '}
                                  <span className="text-sm text-gray-500">
                                    ({getMealTypeLabel(receipt.mealInfo.type)})
                                  </span>
                                </h3>
                              </> : <h3 className="font-medium text-gray-800">
                                {receipt.store}
                              </h3>}
                            {receipt.image && <ImageIcon size={16} className="ml-2 text-gray-400" />}
                          </div>
                          <p className="text-gray-500 text-sm">
                            {new Date(receipt.date).toLocaleDateString()}
                          </p>
                          {!receipt.mealInfo && <p className="text-gray-700 font-medium mt-1">
                              ${receipt.total.toFixed(2)}
                            </p>}
                          <p className="text-gray-500 text-xs mt-1">
                            {receipt.items.length} item
                            {receipt.items.length !== 1 ? 's' : ''}
                          </p>
                        </div>
                        <div className="flex flex-col space-y-2">
                          <button onClick={() => {
                    setSelectedReceipt(receipt);
                    setIsEditing(true);
                  }} className="p-1.5 rounded-full hover:bg-blue-50 text-blue-600" aria-label="Edit receipt">
                            <EditIcon size={18} />
                          </button>
                          <button onClick={() => deleteReceipt(receipt.id)} className="p-1.5 rounded-full hover:bg-red-50 text-red-500" aria-label="Delete receipt">
                            <TrashIcon size={18} />
                          </button>
                        </div>
                      </div>
                    </li>)}
                </ul>}
            </div>
          </> : selectedReceipt ?
      // Receipt Detail View
      <div className="bg-white rounded-xl shadow-sm border border-gray-100 overflow-hidden mb-6">
            <div className="p-4 border-b border-gray-100 bg-gray-50 flex justify-between items-center">
              <h2 className="font-semibold text-gray-800">
                {isEditing ? selectedReceipt.mealInfo ? 'Edit Meal' : 'Edit Receipt' : selectedReceipt.mealInfo ? 'Meal Details' : 'Receipt Details'}
              </h2>
              <button onClick={() => {
            setSelectedReceipt(null);
            setIsEditing(false);
          }} className="p-1 rounded-full hover:bg-gray-200" aria-label="Close">
                <XIcon size={18} className="text-gray-500" />
              </button>
            </div>
            <div className="p-6">
              {isEditing ?
          // Edit Receipt Form
          <div className="space-y-4">
                  <div className="flex gap-4">
                    <div className="w-1/2">
                      <label className="block text-gray-700 text-sm font-medium mb-1">
                        Date
                      </label>
                      <div className="relative">
                        <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
                          <CalendarIcon size={16} className="text-gray-400" />
                        </div>
                        <input type="date" value={selectedReceipt.date} onChange={e => setSelectedReceipt({
                    ...selectedReceipt,
                    date: e.target.value
                  })} className="w-full pl-10 pr-4 py-2 border border-gray-200 rounded-lg" />
                      </div>
                    </div>
                    <div className="w-1/2">
                      <label className="block text-gray-700 text-sm font-medium mb-1">
                        {selectedReceipt.mealInfo ? 'Meal Name' : 'Store'}
                      </label>
                      {selectedReceipt.mealInfo ? <input type="text" value={selectedReceipt.mealInfo.name} onChange={e => handleUpdateMealInfo('name', e.target.value)} className="w-full p-2 border border-gray-200 rounded-lg" placeholder="Meal name" /> : <input type="text" value={selectedReceipt.store} onChange={e => setSelectedReceipt({
                  ...selectedReceipt,
                  store: e.target.value
                })} className="w-full p-2 border border-gray-200 rounded-lg" placeholder="Store name" />}
                    </div>
                  </div>
                  {/* Meal Type (only for meals) */}
                  {selectedReceipt.mealInfo && <div>
                      <label className="block text-gray-700 text-sm font-medium mb-1">
                        Meal Type
                      </label>
                      <select value={selectedReceipt.mealInfo.type} onChange={e => handleUpdateMealInfo('type', e.target.value)} className="w-full p-2 border border-gray-200 rounded-lg">
                        <option value="breakfast">Breakfast</option>
                        <option value="lunch">Lunch</option>
                        <option value="dinner">Dinner</option>
                        <option value="snack">Snack</option>
                      </select>
                    </div>}
                  {/* Receipt Image */}
                  <div>
                    <label className="block text-gray-700 text-sm font-medium mb-1">
                      {selectedReceipt.mealInfo ? 'Meal Photo' : 'Receipt Image'}{' '}
                      (optional)
                    </label>
                    {!selectedReceipt.image ? <div className="border-2 border-dashed border-gray-200 rounded-xl p-6 text-center">
                        <ImageIcon size={24} className="mx-auto text-gray-400 mb-2" />
                        <p className="text-gray-500 mb-2">
                          Add a photo{' '}
                          {selectedReceipt.mealInfo ? 'of your meal' : 'of your receipt'}
                        </p>
                        <label className="cursor-pointer bg-gray-50 hover:bg-gray-100 text-gray-700 py-2 px-4 rounded-lg border border-gray-200 inline-block transition-colors">
                          Upload Image
                          <input type="file" accept="image/*" className="hidden" onChange={handleImageUpload} />
                        </label>
                      </div> : <div className="relative rounded-xl overflow-hidden h-40">
                        <img src={selectedReceipt.image} alt={selectedReceipt.mealInfo ? 'Meal' : 'Receipt'} className="w-full h-full object-cover" />
                        <button onClick={() => setSelectedReceipt({
                  ...selectedReceipt,
                  image: null
                })} className="absolute top-2 right-2 bg-white/80 p-1 rounded-full hover:bg-white text-red-500" aria-label="Remove image">
                          <XIcon size={20} />
                        </button>
                      </div>}
                  </div>
                  {/* Items List */}
                  <div>
                    <div className="flex justify-between items-center mb-2">
                      <label className="block text-gray-700 text-sm font-medium">
                        {selectedReceipt.mealInfo ? 'Ingredients' : 'Items'}
                      </label>
                      <button onClick={handleAddReceiptItem} className="text-sm flex items-center text-red-600 hover:text-red-700">
                        <PlusIcon size={16} className="mr-1" />
                        Add {selectedReceipt.mealInfo ? 'Ingredient' : 'Item'}
                      </button>
                    </div>
                    {selectedReceipt.items.map((item: any, index: number) => <div key={index} className="flex gap-2 items-center mb-2">
                        <input type="text" value={item.name} onChange={e => handleUpdateReceiptItem(index, 'name', e.target.value)} placeholder={selectedReceipt.mealInfo ? 'Ingredient name' : 'Item name'} className="flex-1 p-2 border border-gray-200 rounded-lg" />
                        <input type="number" min="1" value={item.quantity} onChange={e => handleUpdateReceiptItem(index, 'quantity', e.target.value)} className="w-16 p-2 border border-gray-200 rounded-lg" />
                        <input type="text" value={item.unit} onChange={e => handleUpdateReceiptItem(index, 'unit', e.target.value)} placeholder="Unit" className="w-16 p-2 border border-gray-200 rounded-lg" />
                        {!selectedReceipt.mealInfo && <input type="number" min="0" step="0.01" value={item.price} onChange={e => handleUpdateReceiptItem(index, 'price', e.target.value)} placeholder="Price" className="w-20 p-2 border border-gray-200 rounded-lg" />}
                        <button onClick={() => handleRemoveReceiptItem(index)} className="p-1 rounded-full hover:bg-red-50 text-red-500">
                          <TrashIcon size={16} />
                        </button>
                      </div>)}
                  </div>
                  {!selectedReceipt.mealInfo && <div className="flex justify-between items-center pt-4 border-t border-gray-100">
                      <span className="font-medium text-gray-700">Total</span>
                      <span className="text-lg font-bold">
                        ${selectedReceipt.total.toFixed(2)}
                      </span>
                    </div>}
                  <div className="flex gap-2 pt-4">
                    <button onClick={() => {
                setSelectedReceipt(null);
                setIsEditing(false);
              }} className="w-1/2 bg-gray-100 text-gray-700 py-2 rounded-lg">
                      Cancel
                    </button>
                    <button onClick={handleSaveReceipt} className="w-1/2 bg-red-600 text-white py-2 rounded-lg">
                      Save Changes
                    </button>
                  </div>
                </div> :
          // View Receipt Details
          <div className="space-y-4">
                  <div className="flex justify-between">
                    <div>
                      <h3 className="font-bold text-xl text-gray-800">
                        {selectedReceipt.mealInfo ? selectedReceipt.mealInfo.name : selectedReceipt.store}
                      </h3>
                      {selectedReceipt.mealInfo && <div className="flex items-center text-red-600 mt-1">
                          <UtensilsIcon size={16} className="mr-1" />
                          <span>
                            {getMealTypeLabel(selectedReceipt.mealInfo.type)}
                          </span>
                        </div>}
                      <p className="text-gray-500 mt-1">
                        {new Date(selectedReceipt.date).toLocaleDateString()}
                      </p>
                    </div>
                    {!selectedReceipt.mealInfo && <div className="text-right">
                        <p className="text-sm text-gray-500">Total</p>
                        <p className="text-xl font-bold text-gray-800">
                          ${selectedReceipt.total.toFixed(2)}
                        </p>
                      </div>}
                  </div>
                  {selectedReceipt.image && <div className="rounded-xl overflow-hidden h-40 my-4">
                      <img src={selectedReceipt.image} alt={selectedReceipt.mealInfo ? 'Meal' : 'Receipt'} className="w-full h-full object-cover" />
                    </div>}
                  <div className="border-t border-b border-gray-100 py-4">
                    <h4 className="font-medium text-gray-700 mb-2">
                      {selectedReceipt.mealInfo ? 'Ingredients' : 'Items'}
                    </h4>
                    <ul className="space-y-2">
                      {selectedReceipt.items.map((item: any, index: number) => <li key={index} className="flex justify-between">
                          <div>
                            <span className="text-gray-800">{item.name}</span>
                            <span className="text-gray-500 text-sm ml-2">
                              ({item.quantity} {item.unit})
                            </span>
                          </div>
                          {!selectedReceipt.mealInfo && <span className="font-medium">
                              ${(item.price * item.quantity).toFixed(2)}
                            </span>}
                        </li>)}
                    </ul>
                  </div>
                  <div className="flex gap-2 pt-4">
                    <button onClick={() => setIsEditing(true)} className="w-1/2 bg-blue-50 text-blue-600 border border-blue-100 py-2 rounded-lg flex items-center justify-center">
                      <EditIcon size={16} className="mr-1" />
                      Edit {selectedReceipt.mealInfo ? 'Meal' : 'Receipt'}
                    </button>
                    <button onClick={() => handleAddItemsToPantry(selectedReceipt.items)} className="w-1/2 bg-green-50 text-green-600 border border-green-100 py-2 rounded-lg flex items-center justify-center">
                      <PackageIcon size={16} className="mr-1" />
                      Add to Pantry
                    </button>
                  </div>
                </div>}
            </div>
          </div> :
      // Add New Receipt Form
      <div className="bg-white rounded-xl shadow-sm border border-gray-100 overflow-hidden mb-6">
            <div className="p-4 border-b border-gray-100 bg-gray-50 flex justify-between items-center">
              <h2 className="font-semibold text-gray-800">Add New Receipt</h2>
              <button onClick={() => setShowAddReceipt(false)} className="p-1 rounded-full hover:bg-gray-200" aria-label="Close">
                <XIcon size={18} className="text-gray-500" />
              </button>
            </div>
            <div className="p-6">
              <div className="space-y-4">
                <div className="flex gap-4">
                  <div className="w-1/2">
                    <label className="block text-gray-700 text-sm font-medium mb-1">
                      Date
                    </label>
                    <div className="relative">
                      <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
                        <CalendarIcon size={16} className="text-gray-400" />
                      </div>
                      <input type="date" value={newReceipt.date} onChange={e => setNewReceipt({
                    ...newReceipt,
                    date: e.target.value
                  })} className="w-full pl-10 pr-4 py-2 border border-gray-200 rounded-lg" />
                    </div>
                  </div>
                  <div className="w-1/2">
                    <label className="block text-gray-700 text-sm font-medium mb-1">
                      Store
                    </label>
                    <input type="text" value={newReceipt.store} onChange={e => setNewReceipt({
                  ...newReceipt,
                  store: e.target.value
                })} className="w-full p-2 border border-gray-200 rounded-lg" placeholder="Store name" />
                  </div>
                </div>
                {/* Receipt Image */}
                <div>
                  <label className="block text-gray-700 text-sm font-medium mb-1">
                    Receipt Image (optional)
                  </label>
                  {!newReceipt.image ? <div className="border-2 border-dashed border-gray-200 rounded-xl p-6 text-center">
                      <ImageIcon size={24} className="mx-auto text-gray-400 mb-2" />
                      <p className="text-gray-500 mb-2">
                        Add a photo of your receipt
                      </p>
                      <label className="cursor-pointer bg-gray-50 hover:bg-gray-100 text-gray-700 py-2 px-4 rounded-lg border border-gray-200 inline-block transition-colors">
                        Upload Image
                        <input type="file" accept="image/*" className="hidden" onChange={handleImageUpload} />
                      </label>
                    </div> : <div className="relative rounded-xl overflow-hidden h-40">
                      <img src={newReceipt.image} alt="Receipt" className="w-full h-full object-cover" />
                      <button onClick={() => setNewReceipt({
                  ...newReceipt,
                  image: null
                })} className="absolute top-2 right-2 bg-white/80 p-1 rounded-full hover:bg-white text-red-500" aria-label="Remove image">
                        <XIcon size={20} />
                      </button>
                    </div>}
                </div>
                {/* Items List */}
                <div>
                  <div className="flex justify-between items-center mb-2">
                    <label className="block text-gray-700 text-sm font-medium">
                      Items
                    </label>
                    <button onClick={handleAddReceiptItem} className="text-sm flex items-center text-red-600 hover:text-red-700">
                      <PlusIcon size={16} className="mr-1" />
                      Add Item
                    </button>
                  </div>
                  {newReceipt.items.map((item, index) => <div key={index} className="flex gap-2 items-center mb-2">
                      <input type="text" value={item.name} onChange={e => handleUpdateReceiptItem(index, 'name', e.target.value)} placeholder="Item name" className="flex-1 p-2 border border-gray-200 rounded-lg" />
                      <input type="number" min="1" value={item.quantity} onChange={e => handleUpdateReceiptItem(index, 'quantity', e.target.value)} className="w-16 p-2 border border-gray-200 rounded-lg" />
                      <input type="text" value={item.unit} onChange={e => handleUpdateReceiptItem(index, 'unit', e.target.value)} placeholder="Unit" className="w-16 p-2 border border-gray-200 rounded-lg" />
                      <input type="number" min="0" step="0.01" value={item.price} onChange={e => handleUpdateReceiptItem(index, 'price', e.target.value)} placeholder="Price" className="w-20 p-2 border border-gray-200 rounded-lg" />
                      <button onClick={() => handleRemoveReceiptItem(index)} className="p-1 rounded-full hover:bg-red-50 text-red-500">
                        <TrashIcon size={16} />
                      </button>
                    </div>)}
                </div>
                <div className="flex justify-between items-center pt-4 border-t border-gray-100">
                  <span className="font-medium text-gray-700">Total</span>
                  <span className="text-lg font-bold">
                    ${newReceipt.total.toFixed(2)}
                  </span>
                </div>
                <div className="flex gap-2 pt-4">
                  <button onClick={() => setShowAddReceipt(false)} className="w-1/2 bg-gray-100 text-gray-700 py-2 rounded-lg">
                    Cancel
                  </button>
                  <button onClick={handleSaveReceipt} disabled={!newReceipt.store.trim() || newReceipt.items.every(item => !item.name.trim())} className={`w-1/2 ${newReceipt.store.trim() && !newReceipt.items.every(item => !item.name.trim()) ? 'bg-red-600 text-white' : 'bg-gray-200 text-gray-400 cursor-not-allowed'} py-2 rounded-lg`}>
                    Save Receipt
                  </button>
                </div>
              </div>
            </div>
          </div>}
      </main>
    </div>;
}