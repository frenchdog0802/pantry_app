import React, { useState } from 'react';
import { Home } from './components/Home';
import { RecipeSuggestions } from './components/RecipeSuggestions';
import { RecipeDetail } from './components/RecipeDetail';
import { Calendar } from './components/Calendar';
import { PantryManager } from './components/PantryManager';
import { QuickLog } from './components/QuickLog';
import { ShoppingList } from './components/ShoppingList';
import { ReceiptManager } from './components/ReceiptManager';
import { PantryProvider } from './contexts/PantryContext';
export function App() {
  const [currentView, setCurrentView] = useState('home');
  const [selectedRecipe, setSelectedRecipe] = useState(null);
  const navigateToSuggestions = () => {
    setCurrentView('suggestions');
  };
  const navigateToRecipeDetail = recipe => {
    setSelectedRecipe(recipe);
    setCurrentView('recipeDetail');
  };
  const navigateToHome = () => {
    setCurrentView('home');
  };
  const navigateToCalendar = () => {
    setCurrentView('calendar');
  };
  const navigateToPantryManager = () => {
    setCurrentView('pantryManager');
  };
  const navigateToQuickLog = () => {
    setCurrentView('quickLog');
  };
  const navigateToShoppingList = () => {
    setCurrentView('shoppingList');
  };
  const navigateToReceiptManager = () => {
    setCurrentView('receiptManager');
  };
  return <PantryProvider>
      <div className="w-full min-h-screen bg-gray-50">
        {currentView === 'home' && <Home onCookWithWhatIHave={navigateToSuggestions} onViewCalendar={navigateToCalendar} onManagePantry={navigateToPantryManager} onQuickLog={navigateToQuickLog} onShoppingList={navigateToPantryManager} onReceiptManager={navigateToReceiptManager} />}
        {currentView === 'suggestions' && <RecipeSuggestions onSelectRecipe={navigateToRecipeDetail} onBack={navigateToHome} />}
        {currentView === 'recipeDetail' && <RecipeDetail recipe={selectedRecipe} onBack={() => setCurrentView('suggestions')} />}
        {currentView === 'calendar' && <Calendar onBack={navigateToHome} />}
        {currentView === 'pantryManager' && <PantryManager onBack={navigateToHome} onShoppingList={navigateToShoppingList} />}
        {currentView === 'quickLog' && <QuickLog onBack={navigateToHome} onNavigateToReceipts={navigateToReceiptManager} />}
        {currentView === 'shoppingList' && <ShoppingList onBack={navigateToHome} />}
        {currentView === 'receiptManager' && <ReceiptManager onBack={navigateToHome} />}
      </div>
    </PantryProvider>;
}