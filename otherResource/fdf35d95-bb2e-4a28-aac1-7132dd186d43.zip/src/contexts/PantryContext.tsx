import React, { useState, createContext, useContext } from 'react';
import { initialPantryItems } from '../utils/pantryData';
import { recipes } from '../utils/recipeData';
interface CookingHistoryItem {
  date: string; // ISO date string
  recipeId: number | string;
  recipeName: string;
  type?: string; // meal type: breakfast, lunch, dinner, snack
  image?: string | null; // optional meal image
}
interface ShoppingListItem {
  id: string;
  name: string;
  quantity: number;
  unit: string;
  purchased: boolean;
}
interface MealInfo {
  name: string;
  type: string;
}
interface Receipt {
  id: string;
  date: string;
  store: string;
  items: {
    name: string;
    quantity: number;
    unit: string;
    price: number;
  }[];
  total: number;
  image?: string;
  mealInfo?: MealInfo; // Optional field for meal receipts
}
interface PantryItem {
  name: string;
  quantity: number;
  unit: string;
  expiryDate?: string; // Optional expiry date
}
interface PantryContextType {
  pantryItems: PantryItem[];
  recipes: any[];
  cookingHistory: CookingHistoryItem[];
  shoppingList: ShoppingListItem[];
  receipts: Receipt[];
  updatePantryItems: (items: PantryItem[]) => void;
  addToCookingHistory: (recipe: any) => void;
  addToShoppingList: (item: Omit<ShoppingListItem, 'id' | 'purchased'>) => void;
  updateShoppingList: (items: ShoppingListItem[]) => void;
  addReceipt: (receipt: Omit<Receipt, 'id'>) => void;
  updateReceipt: (receipt: Receipt) => void;
  deleteReceipt: (id: string) => void;
}
const PantryContext = createContext<PantryContextType | undefined>(undefined);
export function PantryProvider({
  children
}: {
  children: React.ReactNode;
}) {
  const [pantryItems, setPantryItems] = useState<PantryItem[]>(initialPantryItems);
  const [cookingHistory, setCookingHistory] = useState<CookingHistoryItem[]>([]);
  const [shoppingList, setShoppingList] = useState<ShoppingListItem[]>([]);
  const [receipts, setReceipts] = useState<Receipt[]>([]);
  const updatePantryItems = (items: PantryItem[]) => {
    setPantryItems(items);
  };
  const addToCookingHistory = (recipe: any) => {
    const historyItem: CookingHistoryItem = {
      date: recipe.date || new Date().toISOString().split('T')[0],
      recipeId: recipe.id,
      recipeName: recipe.name,
      type: recipe.type || 'dinner',
      image: recipe.image || null
    };
    setCookingHistory(prev => [...prev, historyItem]);
  };
  const addToShoppingList = (item: Omit<ShoppingListItem, 'id' | 'purchased'>) => {
    const newItem = {
      ...item,
      id: `shopping-${Date.now()}-${Math.random().toString(36).substring(2, 9)}`,
      purchased: false
    };
    setShoppingList(prev => [...prev, newItem]);
  };
  const updateShoppingList = (items: ShoppingListItem[]) => {
    setShoppingList(items);
  };
  const addReceipt = (receipt: Omit<Receipt, 'id'>) => {
    const newReceipt = {
      ...receipt,
      id: `receipt-${Date.now()}-${Math.random().toString(36).substring(2, 9)}`
    };
    setReceipts(prev => [...prev, newReceipt]);
  };
  const updateReceipt = (receipt: Receipt) => {
    setReceipts(prev => prev.map(r => r.id === receipt.id ? receipt : r));
  };
  const deleteReceipt = (id: string) => {
    setReceipts(prev => prev.filter(r => r.id !== id));
  };
  return <PantryContext.Provider value={{
    pantryItems,
    recipes,
    cookingHistory,
    shoppingList,
    receipts,
    updatePantryItems,
    addToCookingHistory,
    addToShoppingList,
    updateShoppingList,
    addReceipt,
    updateReceipt,
    deleteReceipt
  }}>
      {children}
    </PantryContext.Provider>;
}
export function usePantry() {
  const context = useContext(PantryContext);
  if (context === undefined) {
    throw new Error('usePantry must be used within a PantryProvider');
  }
  return context;
}